﻿





//currentboard.MakeMove(playerOne);

//currentboard.CreateBoard();

// Main method

BoardManager currentboard = new BoardManager();
GameManager gameManager = new GameManager();

Console.WriteLine("Player one , please enter your name");
Player playerOne = new Player(Console.ReadLine(), "X");

Console.WriteLine("Player Two , please enter your name");
Player playerTwo = new Player(Console.ReadLine(), "O");

while(true)
{
    currentboard.CreateBoard();
    currentboard.MakeMove(playerOne);
   
    if(gameManager.CheckGame(currentboard,playerOne, playerOne.letter) != true)
    {
        currentboard.CreateBoard();
        currentboard.MakeMove(playerTwo);

        if (gameManager.CheckGame(currentboard, playerTwo ,playerTwo.letter) != true)
        {
            continue;
        }
        else
        {
            break;
        }

    }
    else
    {
        break;
    }


  





}




public class Player
{
    public string name {get; set;}
    public string letter { get; set;}   

    public Player(string name, string letter)
    {
        this.name = name;
        this.letter = letter;
    }
}

public class GameManager
{
 
    public bool CheckGame(BoardManager board,Player player, string letter)//check to see if the game has ended, if so disply result.
    {
        
        if(board.placeOne == letter && board.placeTwo == letter && board.placeThree == letter
            || board.placeFour == letter && board.placeFive == letter && board.placeSix == letter
            || board.placeSeven == letter && board.placeEight == letter && board.placeNine == letter
            || board.placeOne == letter && board.placeFour == letter && board.placeSeven == letter
            || board.placeTwo == letter && board.placeFive == letter && board.placeEight == letter
            || board.placeThree == letter && board.placeSix == letter && board.placeNine == letter
            || board.placeSeven == letter && board.placeFive == letter && board.placeThree == letter
            || board.placeOne == letter && board.placeFive == letter && board.placeNine == letter)
        {
            Console.WriteLine($"{player.name} Wins!!");
            return true;
        }
        else if(board.placeOne != " " && board.placeTwo != " " && board.placeThree != " "
            && board.placeFour != " " && board.placeFive != " " && board.placeSix != " "
            && board.placeSeven != " " && board.placeEight != " " && board.placeNine != " ")
        {
            Console.WriteLine("Draw");
            return true;
        }

        return false;
    }

}


public class BoardManager
{
    public string placeOne = " ";
    public string placeTwo = " ";  
    public string placeThree = " ";
    public string placeFour = " ";
    public string placeFive = " ";
    public string placeSix = " ";
    public string placeSeven = " ";
    public string placeEight = " ";
    public string placeNine = " ";


    public void CreateBoard()
    {
       
        Console.WriteLine($"{placeSeven}|{placeEight}|{placeNine}");
        Console.WriteLine("-+-+-");
        Console.WriteLine($"{placeFour}|{placeFive}|{placeSix}");
        Console.WriteLine("-+-+-");
        Console.WriteLine($"{placeOne}|{placeTwo}|{placeThree}");
       
    }

   

    public void MakeMove(Player player)
    {
        
        while(true)
        {
            Console.WriteLine($"{player.name} please enter move");
            int moveLocation = Convert.ToInt32(Console.ReadLine());

            switch (moveLocation)
            {
                case 1:
                    if(placeOne != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                    }
                    else
                    {
                        placeOne = player.letter;
                       
                    }
                    break;

                case 2:
                    if (placeTwo != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                       ;
                    }
                    else
                    {
                        placeTwo = player.letter;
                        break;
                    }

                case 3:
                    if (placeThree != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                        ;
                    }
                    else
                    {
                        placeThree = player.letter;
                        break;
                    }
                case 4:
                    if (placeFour != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                        
                    }
                    else
                    {
                        placeFour = player.letter;
                        break;
                    }
                case 5:
                    if (placeFive != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                        
                    }
                    else
                    {
                        placeFive = player.letter;
                        break;
                    }
                case 6:
                    if (placeSix != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                        
                    }
                    else
                    {
                        placeSix = player.letter;
                        break;
                    }
                case 7:
                    if (placeSeven != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                        
                    }
                    else
                    {
                        placeSeven = player.letter;
                        break;
                    }
                case 8:
                    if (placeEight != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                        
                    }
                    else
                    {
                        placeEight = player.letter;
                        break;
                    }
                case 9:
                    if (placeNine != " ")
                    {
                        Console.WriteLine("Already Taken");
                        continue;
                      
                    }
                    else
                    {
                        placeNine = player.letter;
                        break;
                    }
                    

            }
            break;
        }
     

    }


}














